/* eslint-env node */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
