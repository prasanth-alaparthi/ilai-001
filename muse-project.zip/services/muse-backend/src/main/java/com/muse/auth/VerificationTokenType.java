package com.muse.auth;

public enum VerificationTokenType {
    EMAIL_VERIFY,
    PASSWORD_RESET
}