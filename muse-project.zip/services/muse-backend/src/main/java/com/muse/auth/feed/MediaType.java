package com.muse.auth.feed;


public enum MediaType {
    IMAGE,
    VIDEO,
    AUDIO,
    OTHER
}