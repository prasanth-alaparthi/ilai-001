package com.muse.auth.feed;


public enum PostVisibility {
    PUBLIC,
    CLASS,       // later: restrict by class/course
    UNIVERSITY,  // later: restrict by institution
    PRIVATE
}