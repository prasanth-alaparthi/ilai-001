package com.muse.auth.feed.service;

import org.springframework.stereotype.Service;

@Service
public class ModerationNotificationService {
    public void notifyInstitution(Long institutionId, String message) {
        // Placeholder implementation
    }

    public void notifyTeacherOrAdmins(String authorUsername, String message) {
        // Placeholder implementation
    }
}
