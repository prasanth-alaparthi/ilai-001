package com.muse.auth.flash.repository;

import com.muse.auth.flash.entity.UserXp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserXpRepository extends JpaRepository<UserXp, String> {
}
