-- V1_1__enable_vector_extension.sql
-- Enable the vector extension for embedding support

CREATE EXTENSION IF NOT EXISTS vector;
