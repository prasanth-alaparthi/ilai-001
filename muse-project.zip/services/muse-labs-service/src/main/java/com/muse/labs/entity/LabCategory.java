package com.muse.labs.entity;

public enum LabCategory {
    MATH,
    PHYSICS,
    CHEMISTRY,
    BIOLOGY,
    CS
}
