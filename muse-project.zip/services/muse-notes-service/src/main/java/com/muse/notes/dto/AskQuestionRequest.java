package com.muse.notes.dto;

import lombok.Data;

@Data
public class AskQuestionRequest {
    private String question;
}
