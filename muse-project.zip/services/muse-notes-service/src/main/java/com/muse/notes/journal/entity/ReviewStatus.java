package com.muse.notes.journal.entity;

public enum ReviewStatus {
    SUBMITTED,
    UNDER_REVIEW,
    ACCEPTED,
    REVISION_REQUESTED,
    REJECTED
}
