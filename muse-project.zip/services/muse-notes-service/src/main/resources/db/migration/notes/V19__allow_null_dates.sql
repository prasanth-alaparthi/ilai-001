ALTER TABLE calendar_events ALTER COLUMN start_time DROP NOT NULL;
ALTER TABLE calendar_events ALTER COLUMN end_time DROP NOT NULL;
